const express = require('express');
const crypto = require('crypto');
const app = express();
app.use(express.json());
app.use(express.static('public'));

// DEMO ONLY: data lives in memory and resets when the server restarts.
// Replace the demo password with an environment variable before publishing.
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'change-this-demo-password';
let users = [
  { id: 1, username: 'player1', balance: 100, history: [] },
  { id: 2, username: 'player2', balance: 250, history: [] }
];
let promos = [];
const sessions = new Set();

function adminOnly(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (!token || !sessions.has(token)) return res.status(401).json({ error: 'Нужен вход администратора' });
  next();
}
app.post('/api/admin/login', (req, res) => {
  if ((req.body.password || '') !== ADMIN_PASSWORD) return res.status(401).json({ error: 'Неверный пароль' });
  const token = crypto.randomBytes(24).toString('hex'); sessions.add(token);
  res.json({ token });
});
app.get('/api/admin/users', adminOnly, (req, res) => res.json(users));
app.post('/api/admin/balance', adminOnly, (req, res) => {
  const user = users.find(u => u.id === Number(req.body.userId));
  const amount = Number(req.body.balance);
  if (!user || !Number.isFinite(amount) || amount < 0 || amount > 1000000000) return res.status(400).json({ error: 'Проверь игрока и баланс' });
  user.balance = Math.round(amount * 100) / 100;
  user.history.unshift({ type: 'Изменение администратором', balance: user.balance, at: new Date().toISOString() });
  res.json({ ok: true, user });
});
app.post('/api/admin/promos', adminOnly, (req, res) => {
  const code = String(req.body.code || '').trim().toUpperCase();
  const amount = Number(req.body.amount);
  if (!/^[A-Z0-9_-]{3,24}$/.test(code) || !Number.isFinite(amount) || amount <= 0 || amount > 1000000) return res.status(400).json({ error: 'Код: 3–24 символа A–Z/цифры; награда должна быть больше нуля' });
  if (promos.some(p => p.code === code)) return res.status(409).json({ error: 'Такой промокод уже есть' });
  const promo = { code, amount: Math.round(amount * 100) / 100, createdAt: new Date().toISOString() };
  promos.unshift(promo); res.json({ ok: true, promo });
});
app.get('/api/admin/promos', adminOnly, (req, res) => res.json(promos));
app.get('/api/player/:username', (req, res) => {
  const user = users.find(u => u.username.toLowerCase() === String(req.params.username).toLowerCase());
  if (!user) return res.status(404).json({ error: 'Игрок не найден. Для теста используй player1 или player2.' });
  res.json({ username: user.username, balance: user.balance, history: user.history });
});
app.post('/api/player/:username/redeem', (req, res) => {
  const user = users.find(u => u.username.toLowerCase() === String(req.params.username).toLowerCase());
  const code = String(req.body.code || '').trim().toUpperCase();
  if (!user) return res.status(404).json({ error: 'Игрок не найден' });
  const promo = promos.find(p => p.code === code);
  if (!promo) return res.status(400).json({ error: 'Промокод не найден' });
  if (user.history.some(h => h.type === 'Промокод ' + code)) return res.status(409).json({ error: 'Этот промокод уже использован' });
  user.balance = Math.round((user.balance + promo.amount) * 100) / 100;
  user.history.unshift({ type: 'Промокод ' + code, amount: promo.amount, balance: user.balance, at: new Date().toISOString() });
  res.json({ ok: true, username: user.username, balance: user.balance });
});
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Demo server listening on ${port}`));
